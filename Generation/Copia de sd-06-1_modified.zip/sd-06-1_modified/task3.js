// Type your code below this line!

function Mail(subj, msg) {
    this.subject = subj
    this.message = msg
    
  }
  
  const newMail = new Mail(  )
  
  // Type your code above this line!
  
  newMail.printMail()