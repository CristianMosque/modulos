// Refer to Task 7 in your Instructions to complete this task

let buzzWords = [
    "Fizz",
    "Buzz",
    "Woof",
    "Bark",
    "Awoo",
    "Bang"
  ];
  
  for (let i = 0; i < 1; i++) {
    console.log("This is Task Seven!");
  };