// Refer to Task 1 in your Instructions to complete this task

for (let i = 0; i < 1; i++) {
    console.log("This is Task One!");
  };