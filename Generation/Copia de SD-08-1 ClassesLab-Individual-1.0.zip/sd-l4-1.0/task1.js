export class Player {
    constructor() {
      
    }
  
    
  }